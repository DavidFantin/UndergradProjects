//NOT COMPLETE WILL UPDATE ASAP

import edu.utulsa.unet.UDPSocket;
import java.io.File;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.net.SocketException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.DatagramPacket;
import java.net.SocketTimeoutException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.concurrent.locks.*;
import java.lang.*;
import edu.utulsa.unet.RSendUDPI;

public class RSendUDP implements RSendUDPI {
	
/////////////////////////////////////////////
	char AckBit = '0';

	public RSendUDP() {
		Mode = 1;
		WindowSize = 256;
		Timeout = 1000;
		LocalPort = 12987;
		Receiver = new InetSocketAddress("127.0.0.1", 12987);
	}

//////////////////////////////////////////////////////////////////////////////
	public boolean setMode(int mode) {
		Mode = mode;
		return true;
	}

	public int getMode() {
		return Mode;
	}

//
	public boolean setModeParameter(long parameter) {
		WindowSize = parameter;
		return true;
	}

	public long getModeParameter() {
		return WindowSize;
	}

//
	public boolean setTimeout(long time) {
		Timeout = time;
		return true;
	}

	public long getTimeout() {
		return Timeout;
	}

//
	public void setFilename(String name) {
		FName = name;
	}

	public String getFilename() {
		return FName;
	}

	//
	public boolean setLocalPort(int portnumber) {
		LocalPort = portnumber;
		return true;
	}

	public int getLocalPort() {
		return LocalPort;
	}

	public boolean setReceiver(InetSocketAddress addr) {
		Receiver = addr;
		return true;
	}

	public InetSocketAddress getReceiver() {
		return Receiver;
	}
////////////////////////////////////////////////////////////////////////////////////////

	public boolean sendFile() {
		if (Mode == 0) {
			boolean s = StopAndWait();
			return s;
		} else if (Mode == 1) {
			return SlidingWindow();
		} else {
			System.out.println("No Associated Mode [0 for stop and wait, 1 for sliding window]");
			return false;
		}
	}

	public boolean StopAndWait() {
		customHeaderSize = 8;
		fullHeaderSize = customHeaderSize + 28;
		long start = System.currentTimeMillis();
		try {
			@SuppressWarnings("resource")
			UDPSocket socket = new UDPSocket(LocalPort);

			MTU = socket.getSendBufferSize();
			if (MTU < 38) {
				System.out.println("MTU is not large enough to send any data.");
				return false;
			}

			File file = new File(FName);
			Receiver.getAddress();
			System.out.println("Sending " + FName + " from " + InetAddress.getLocalHost() + ":" + LocalPort
					+ " to " + Receiver.getAddress().getHostAddress() + ":" + Receiver.getPort() + " with "
					+ file.length() + " bytes Using stop-and-wait");
			FileReader fr = new FileReader(file);
			String str = "";
			long msgNum = 1;
			boolean Continue = true;
			long sendtime = System.currentTimeMillis();
			while (Continue) {

				str += AckBit;
				for (int i = MTU - fullHeaderSize; i != 0; i--) {
					int c = fr.read();
					if (c != -1) {
						str += (char) c;
					} else {
						Continue = false;
						break;
					}
				}
				int size = 8 + str.getBytes().length;
				byte[] buffer = new byte[size];
				byte[] strBuffer = str.getBytes();
				long PacketExp = System.currentTimeMillis() + (2 * Timeout);
				ByteBuffer preBuffer = ByteBuffer.allocate(Long.BYTES);
				preBuffer.putLong(PacketExp);
				byte[] Exp = preBuffer.array();
				System.arraycopy(Exp, 0, buffer, 0, Exp.length);
				System.arraycopy(strBuffer, 0, buffer, 8, strBuffer.length);

				while (System.currentTimeMillis() - sendtime <= Timeout) {
				}
				;
				socket.send(new DatagramPacket(buffer, buffer.length, Receiver));
				sendtime = System.currentTimeMillis();
				if (str.length() > 1) {
					System.out.println(
							"Message " + msgNum + " sent with " + (str.length() - 1) + " bytes of actual data");
				}
				long packetSendTime = System.currentTimeMillis();
				int count = 0;
				boolean Received = true;
				while (Received) {
					try {
						socket.setSoTimeout((int) Timeout);
						byte[] intake = new byte[1];
						DatagramPacket packet = new DatagramPacket(intake, intake.length);
						socket.receive(packet);
						String rcv = new String(intake);
						System.out.println(rcv);
						if (rcv.charAt(0) == AckBit) {
							break;
						}

					} catch (SocketTimeoutException e) {
						if (count == 100) {
							System.out.println("Exiting: No response for 10 cycles");
							return false;
						}
						while (System.currentTimeMillis() - sendtime <= Timeout) {
						}
						socket.send(new DatagramPacket(buffer, buffer.length, Receiver));
						sendtime = System.currentTimeMillis();
						System.out.println("Message " + msgNum + " Timed-Out");
						count += 1;
					}

				}

				System.out.println("Message " + msgNum + " acknowledged");

				if (AckBit == '0') {
					AckBit = '1';
				} else {
					AckBit = '0';
				}
				str = "";
				msgNum += 1;
			}

			long time = System.currentTimeMillis() - start;
			double seconds = ((double) time) / 1000;
			System.out.println(
					"Successfully transferred " + FName + " (" + file.length() + ") in " + seconds + " seconds.");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;

	}

	public boolean SlidingWindow() {
		int LAR = 0; // left side of window
		int LFS = 0; // right side of window
		customHeaderSize = 4; // 4 bits for sequence number
		fullHeaderSize = customHeaderSize + 28;
		try {

			UDPSocket socket = new UDPSocket(LocalPort);
			MTU = socket.getSendBufferSize();
			MaxOutstanding = (int) (WindowSize / MTU);
			if (MTU < fullHeaderSize) {
				System.out.println("MTU is too low to send any data!");
				return false;
			}

			File file = new File(FName);
			System.out.println("Sending " + FName + " from " + Receiver.getAddress().getLocalHost() + ":" + LocalPort
					+ " to " + Receiver.getAddress().getHostAddress() + ":" + Receiver.getPort() + " with "
					+ file.length() + " bytes Using stop-and-wait");

			Path path = Paths.get(FName);
			byte[] data = Files.readAllBytes(path);
			startIndex = 0;
			dataSize = MTU - fullHeaderSize;
			int remainderSize = data.length % dataSize;
			int FAL = (data.length - remainderSize) / dataSize + 1;
			byte[][] FinalArray = new byte[FAL][];

			while (true) {
				if (dataSize <= (data.length - remainderSize)) {
					for (int i = 0; i <= (data.length - remainderSize); i += dataSize) { /////////////////////////////////////
						byte[] dataSlice = Arrays.copyOfRange(data, startIndex + i, dataSize + i);
						byte[] packet = packetBuilder(sequenceNumber, dataSlice);
//						System.out.println(sequenceNumber);
						FinalArray[sequenceNumber] = packet;
//						System.arraycopy(packet, 0, FinalArray, i, dataSize); /// this should iterate though and put all arrays into the FinalArray

						sequenceNumber++;
					}
					if (remainderSize != 0) {
						byte[] dataSlice = Arrays.copyOfRange(data, (data.length - remainderSize), (data.length));
//						System.out.println(FAL - 1);
						byte[] packet = packetBuilder(FAL - 1, dataSlice);
						FinalArray[FAL - 1] = packet; // puts packet into final array
//						System.arraycopy(packet, 0, FinalArray[j], FAL-1, dataSize);

					}
				} else {
					byte[] dataSlice = Arrays.copyOfRange(data, 0, (data.length - 1));
//					System.out.println(sequenceNumber);
					byte[] packet = packetBuilder(sequenceNumber, dataSlice);
					FinalArray[0] = packet;
//					System.arraycopy(packet, 0, FinalArray[0], 0, dataSize);
				}
				for (int i = 0; i < FinalArray.length; i++) { // send data
					
					
					
					
					
				}
				
				
				
				
			
				
				
/////////////////**************************************************//////////////////
				for (int i = 0; i < FinalArray.length; i++) {
					System.out.println(Arrays.toString(row));
				}
				break;
/////////////////**************************************************//////////////////
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;
	}

	public byte[] packetBuilder(int SequenceNumber, byte[] DataSlice) {

		byte[] SeqNum = toByteArray(SequenceNumber);
//		System.out.println(Arrays.toString(SeqNum));
		
		int SNL = SeqNum.length;
		int DSL = DataSlice.length;

		byte[] packet = new byte[SNL + DSL];
		System.arraycopy(SeqNum, 0, packet, 0, SNL);
		System.arraycopy(DataSlice, 0, packet, SNL, DSL);

		return packet; // packet == buffer
	}
	public byte[] toByteArray(int i) {
		
	  byte[] result = new byte[4];

	  result[0] = (byte) (i >> 24);
	  result[1] = (byte) (i >> 16);
	  result[2] = (byte) (i >> 8);
	  result[3] = (byte) (i >> 0);

	  return result;
	}

	int Mode;
	int MTU;
	int customHeaderSize;
	int fullHeaderSize;
	int MaxOutstanding;
	int startIndex;
	int dataSize;
	int sequenceNumber = 0;
	int LocalPort;
	long WindowSize;
	long Timeout;
	String FName;
	InetSocketAddress Receiver;
	
	
}









































//import java.io.*;
//import java.net.DatagramPacket;
//import edu.utulsa.unet.*;
//import java.net.InetAddress;
//import java.net.InetSocketAddress;
//import java.util.*;
//
//public class RSendUDP implements RSendUDPI{
////	DatagramPacket packet = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(serverName), serverPort));	
//
//	public RSendUDP() {
//		Mode = 0;
//		WindowSize = 256;
//		Timeout = 1000;
//		sPort = 12987;
//		localhost = "127.0.0.1";
//		Receiver = new InetSocketAddress(localhost, rPort);
//	}
//	
//	public boolean setMode(int mode) {
//		// 0 = reliable delivery
//		// 1 = sliding window
//		Mode = mode;
//		return true;
//	}
//	public int getMode() {
//		// returns 1 or 0
//		return Mode;
//	}
//	// size of window in bytes
//	public boolean setModeParameter(long n) {
//		// set default value = 256
//		WindowSize = n;
//		return true;
//	}
//	public long getModeParameter() {
//		return WindowSize;
//	}
//	public void setFilename(String fname) {
//		FName = fname;
//	}
//	public String getFilename() {
//		return FName;
//	}
//	public boolean setTimeout(long timeout) {
//		Timeout = timeout;
//		return true;
//	}
//	public long getTimeout() {
//		return Timeout;
//	}
//	public boolean setLocalPort(int port) {
//		sPort = port;
//		return true;
//	}
//	public int getLocalPort() {
//		return sPort;
//	}
//	public boolean setReceiver(InetSocketAddress receiver) {
//		if (receiver.getHostName().isEmpty()) {
//			rPort = receiver.getPort();
//		}
//		else {
//			Receiver = receiver;	
//		}
//		return true;		
//	}
//	public InetSocketAddress getReceiver() {
//		return Receiver;
//	}
//	public boolean sendFile() {
//		if (Mode == 0) {
//			Success = StopAndWait();
//		}
//		else if (Mode == 1) {
//			Success = SlidingWindow();
//		}
//		
//		if (Success) {
//			return true;
//		}
//		else {
//			return false;
//		}
//	}
//	
//	public static List<String> splitEqually(String text, int size) {
//	    // Give the list the right capacity to start with. You could use an array
//	    // instead if you wanted.
//	    List<String> ret = new ArrayList<String>((text.length() + size - 1) / size);
//
//	    for (int start = 0; start < text.length(); start += size) {
//	        ret.add(text.substring(start, Math.min(text.length(), start + size)));
//	    }
//	    return ret;
//	}
//
//	
//	@SuppressWarnings("resource")
//	public boolean StopAndWait() {
//		customHeaderSize = 9;
//		try {
//			UDPSocket socket = new UDPSocket(sPort);
//			MTU = socket.getSendBufferSize();
//
//			
//			
//			
//			
//			List<String> strlist = new ArrayList<String>();
//			File file = new File(FName);
//			System.out.println("Sending " + FName + " from " + Receiver.getAddress().getLocalHost() + ":" 
//								+ sPort + " to " + Receiver.getAddress().getHostAddress() + ":" + Receiver.getPort() 
//								+ " with " + file.length() + " bytes Using stop-and-wait" );
//			int packetDataLeftOver = (int) (file.length() % (MTU - (28 + customHeaderSize)));
//			int packetDataCount = (int) ((file.length() - packetDataLeftOver) / (MTU - (28 + customHeaderSize)));
//			
//			String str = "";
//		    FileInputStream fis = new FileInputStream(file);
//		    boolean loopcont = true;
//		    while(loopcont) {
//		    	str += ackcheck;
//		    	for(int i = MTU - (28 + customHeaderSize); i != 0; i--) {
//		    		int k = fis.read();
//		    		if(k != -1) {
//		    			str += (char) k;
//		    		}
//		    		else {
//		    			loopcont = false;
//		    			break;
//		    		}
//		    	}
//		    }
//		    
//		    
////		    StringBuilder sb = new StringBuilder();
////		    for (int i = 0; i < str.length(); i++) {
////		        if (i > 0 && (i % 100 == 0)) {
////		            sb.append("\n");
////		        }
////
////		        sb.append(str.charAt(i));
////		    }
////
////		    str = sb.toString();
//		    
////				StringBuilder sb = new StringBuilder();
////				char character = (char) ch;
////				sb.append(character);
////				
////					String str = sb.toString();
////					packetData.concat(str);
////				
////				}
////				strlist.add(packetData);
////			}
//			
//			byte [] buffer = content.getBytes();
////			System.out.println(buffer);
//			for (String elm : strlist) {
////			    System.out.println(elm);
//			}
//
//		}
//		catch(Exception e){
//			e.printStackTrace();
//		}
//		
//			return true;
//	}
//	
//	private boolean SlidingWindow() {
//		customHeaderSize = (int) WindowSize;
//		return true;
//	}
//	
//	int Mode;
//	long WindowSize;
//	String FName;
//	long Timeout;
//	int sPort;
//	int rPort;
//	InetSocketAddress Receiver;
//	String localhost;
//	boolean Success;
//	int MTU;
//	String packetData;
//	int customHeaderSize;
//	int ackcheck;
//	
//
//}
