//NOT COMPLETE WILL UPDATE ASAP

import edu.utulsa.unet.UDPSocket;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import edu.utulsa.unet.RReceiveUDPI;
import java.nio.ByteBuffer;
import java.io.File;
import java.util.*;

public class RReceiveUDP implements RReceiveUDPI {

	public RReceiveUDP() {
		Mode = 0;
		WindowSize = 256;
		localPort = 12987;
	}

///
	public boolean setMode(int mode) {
		Mode = mode;
		return true;
	}

	public int getMode() {
		return Mode;
	}

///
	public boolean setModeParameter(long windowSize) {
		WindowSize = windowSize;
		return true;
	}

	public long getModeParameter() {
		return WindowSize;
	}

///
	public void setFilename(String fname) {
		FName = fname;
	}

	public String getFilename() {
		return FName;
	}

///
	public boolean setLocalPort(int portnumber) {
		localPort = portnumber;
		return true;
	}

	public int getLocalPort() {
		return localPort;
	}
///

	public boolean receiveFile() {
		if (Mode == 0) {
			return StopAndWait();
		} else if (Mode == 1) {
			return SlidingWindow();
		} else {
			System.out.println("No Associated Mode [0 for stop and wait, 1 for sliding window]");
			return false;
		}
	}

	public boolean StopAndWait() {
		try {
			UDPSocket socket = new UDPSocket(localPort);
			String AckBit = "0";
			File file = new File(FName);
			file.createNewFile();
			boolean running = true;
			System.out.println("Receiving " + FName + " to " + socket.getLocalAddress().getHostAddress() + ": " + localPort);

			long msgNum = 0;
			while (running) {
				msgNum ++;
				int returnedData = socket.getSendBufferSize() - 38;
				byte[] inbuffer = new byte[socket.getSendBufferSize() - 28];
				DatagramPacket packet = new DatagramPacket(inbuffer, inbuffer.length);
				socket.receive(packet);
				ByteBuffer bb = ByteBuffer.wrap(inbuffer);
				byte[] ExpTime = new byte[8];
				bb.get(ExpTime, 0, 8);
				ByteBuffer pl = ByteBuffer.allocate(Long.BYTES);
				pl.put(ExpTime);
				pl.flip();
				long Time = pl.getLong();
				if (!(System.currentTimeMillis() < Time)) {
					byte[] buffer = new byte[socket.getSendBufferSize() - 36];
					bb.get(buffer, 0, buffer.length);

					String msg = new String(buffer);
					if (msgNum == 1) {
						System.out.println(
								"Packet Incoming From " + packet.getAddress() + " On Port " + packet.getPort());
					}
					System.out.println("Packet " + msg.charAt(0) + " has been Received with " + (msg.length() - 1)
							+ " bytes" + "  :  " + msg);

					if (AckBit.charAt(0) == msg.charAt(0)) {

						
//						FileWriter fw = new FileWriter(file, true);
						BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));


						for (int i = 1; i < returnedData + 2; i++) {
							if (msg.charAt(i) != '\u0000') {
								bw.write(msg.charAt(i));
							} else {
								running = false;
								break;
							}

						}
						bw.close();

						if (AckBit == "0") {
							AckBit = "1";
						} else {
							AckBit = "0";
						}
					}
					// send ack
					byte[] send = Character.toString(msg.charAt(0)).getBytes();
					socket.send(new DatagramPacket(send, send.length, packet.getAddress(), packet.getPort()));
					if (finish) {
						System.out.println("Successfully Received " + file.length() + " bytes Stored In " + FName);
					} else {
						System.out.println("Acknowledging " + msg.charAt(0));
					}

				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;
	}

	public boolean SlidingWindow() {
		
		
		// use an arraylist to receive
		
		
		ArrayList str = new ArrayList();
		
		
		
		
		
		
		try{
	 	UDPSocket socket = new UDPSocket(localPort);
		    while(true){
			byte [] buffer = new byte[80];
			DatagramPacket packet = new DatagramPacket(buffer,buffer.length);
			socket.receive(packet);
		
		
		
		
		
		
		
		
		
		return true;
	}
} catch (Exception e) {
	e.printStackTrace();
}
	}

	int Mode;
	long WindowSize;
	String FName;
	int localPort;

}

































































//import java.net.DatagramPacket;
//import edu.utulsa.unet.*;
//import java.net.InetAddress;
//import java.net.InetSocketAddress;
//
//public class RReceiveUDP implements RReceiveUDPI{
////	byte [] buffer = new byte[??????????];
////	DatagramPacket packet = new DatagramPacket(buffer,buffer.length);
//	public RReceiveUDP() {
//		N = 256;
//		rPort = 12987;
//	}
//	public boolean setMode(int mode) {
//		Mode = mode;
//		return true;
//	}
//	public int getMode() {
//		return Mode;
//	}
//	public boolean setModeParameter(long n) {
//		N = n;
//		return true;
//	}
//	public long getModeParameter() {
//		return N;
//	}
//	public void setFilename(String fname) {
//		FName = fname;
//	}
//	public String getFilename() {
//		return FName;
//	}
//	public boolean setLocalPort(int port) {
//		rPort = port;
//		return true;
//	}
//	public int getLocalPort() {
//		return rPort;
//	}
//	public boolean receiveFile() {
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		return true;
//	}
//	
//	
//	int Mode;
//	long N;
//	String FName;
//	long Timeout;
//	int rPort;
//	InetSocketAddress Receiver;
//	String localhost = "127.0.0.1";
//
//
//}
