#include <stdio.h>

int main(int argc, char **argv){
    
    char name[780];
    
    printf("Please enter your name: ");
    scanf("%[^\n]", name);
    printf("Hello, %s\n", name);
    
    return 0;
}
