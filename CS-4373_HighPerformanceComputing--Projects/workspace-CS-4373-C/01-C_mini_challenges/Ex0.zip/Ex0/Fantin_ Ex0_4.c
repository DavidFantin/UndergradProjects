#include <stdio.h>
#include <math.h>
#include <time.h>

int main(int argc, char **argv){

    clock_t startMulti, endMulti, startDiv, endDiv, startSqrt, endSqrt, startSin, endSin;
    double time_usedMulti, time_usedDiv, time_usedSqrt, time_usedSin;

    startMulti = clock();
    for(int n = 0; n < 1000000000; n++){
        ((n+1) * n);
    }
    endMulti = clock();

    startDiv = clock();
    for(int n = 0; n < 1000000000; n++){
        (n+1 / n);
    }
    endDiv = clock();
    
    startSqrt = clock();
    for(int n = 0; n < 1000000000; n++){
        sqrt(n+1);
    }
    endSqrt = clock();
    
    startSin = clock();
    for(int n = 0; n < 100000000; n++){
        sin(n+1);
    }
    endSin = clock();
    
    time_usedMulti = ((double) (endMulti - startMulti)) / CLOCKS_PER_SEC;
    time_usedDiv = ((double) (endDiv - startDiv)) / CLOCKS_PER_SEC;
    time_usedSqrt = ((double) (endSqrt - startSqrt)) / CLOCKS_PER_SEC;
    time_usedSin = ((double) (endSin - startSin)) / CLOCKS_PER_SEC;
    printf("Time elapsed for *: %lf seconds.\n", time_usedMulti);
    printf("Time elapsed for /: %lf seconds.\n", time_usedDiv);
    printf("Time elapsed for sqrt: %lf seconds.\n", time_usedSqrt);
    printf("Time elapsed for sin: %lf seconds.\n", time_usedSin);

    return 0;
}
