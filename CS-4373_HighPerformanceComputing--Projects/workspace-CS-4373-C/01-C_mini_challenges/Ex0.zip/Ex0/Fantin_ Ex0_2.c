#include <stdio.h>
#include <math.h>
#include <time.h>

int main(int argc, char **argv){
    
    float pi_approx;
    clock_t start, end;
    double time_used;

    start = clock();
    for(int n = 3; n <= 100; n = n * 2){
        pi_approx = sin((180 / 57.29577951308232) / n) * n;
	printf("Pi approximated using a polynomial of %d sides is: %.20lf\n", n, pi_approx);
    }
    end = clock();

    time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("Time elapsed: %lf seconds.\n", time_used);

    return 0;
}
