#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

int main(int argc, char **argv){
    clock_t start, end;
    double time_used;
    
    start = clock();

    FILE* file = fopen("mv.txt", "r");

    int i = 0;
   
    fscanf(file, "%d", &i);
    int numRows = i;
   
    fscanf(file, "%d", &i);
    int numCols = i;

    int numElms = numRows * numCols;
    int mArray[numElms];

    for(int n = 0; n < numElms; n++){
        fscanf(file, "%d", &i);
	mArray[n] = i;
    }

    fscanf(file, "%d", &i);
    int vecSize = i;
    int vArray[vecSize];
    if(vecSize != numCols){
    	printf("Error, the inputed matrix and vector are incomplatable.\nPlease try again...");
	exit(1);
    }

    for(int n = 0; n < vecSize; n++){
        fscanf(file, "%d", &i);
	vArray[n] = i;
    }

    int sum = 0;
    for(int n = 0; n < numCols; n++){
        sum = sum + mArray[n] * vArray[n % vecSize];
	if((n == numCols - 1) && (numCols <= numElms)){
	     numCols = numCols + 10;
             printf("%d\n", sum);
	     sum = 0;
	}
    }

    fclose(file);
    
    end = clock();
    
    time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("\nTime elapsed: %lf seconds.\n", time_used);

    return 0;
}


